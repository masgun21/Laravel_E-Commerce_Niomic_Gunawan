<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\Utama;
use App\Http\Controllers\Login;
use App\Http\Controllers\Order;

Route::get('/Login', [Login::class, 'index']); 
Route::Post('/Daftar', [Login::class, 'Register']);
Route::Post('/Masuk', [Login::class, 'Masuk']);
Route::get('/Keluar', [Login::class, 'Keluar']);


Route::get('/', [Utama::class, 'index']);
Route::post('/pushData', [Utama::class, 'store']);

Route::post('/AddCart', [Order::class, 'Order']);
Route::get('/Keranjang', [Order::class, 'Keranjang']);
Route::get('/Checkout', [Order::class, 'Checkout']); 


